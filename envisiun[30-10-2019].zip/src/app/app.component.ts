import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  template: `<router-outlet></router-outlet>`,
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  constructor(private router: Router,) {
    this.router.events.subscribe((evt) => {
      if(evt instanceof NavigationEnd) {
        window.scrollTo(0, 0);
      }
    });
  }
  
}
