import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailVerifyComponent } from './email-verify/email-verify.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from './../../shared/shared.module';
import { EmailVerifyResolver } from './email-verify/email-verify-resolver.service';
import { UserLoginComponent } from './user-login/user-login.component';
import { AlertModule } from '../alert/alert.module';

const authRoutes: Routes = [
  {
    path: 'email_verify/:token',
    component: EmailVerifyComponent,
    // resolve: { email_verify : EmailVerifyResolver }
  },
  {
    path: '',
    redirectTo: 'email_verify',
    pathMatch: 'full'
  },
]

@NgModule({
  declarations: [EmailVerifyComponent, UserLoginComponent],
  imports: [
    CommonModule,
    SharedModule,
    AlertModule,
    RouterModule.forChild(authRoutes)
  ],
  providers: [ EmailVerifyResolver ]
})
export class AuthModule { }
