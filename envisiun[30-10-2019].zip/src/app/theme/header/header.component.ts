import { Component, OnInit, AfterViewInit } from '@angular/core';
declare var $: any;
import * as AOS from 'aos';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, AfterViewInit {
  

  constructor() {   }

  ngOnInit() {
    AOS.init();
  }

  ngAfterViewInit(): void {
    //navigation js
    $(".menu-toggle").click(function(){
      $(this).addClass("active");
    $("#main-navigation").addClass("active");
    });

    $(".nav-close-btn").click(function(){
    $("#main-navigation").removeClass("active");
    $(".menu-toggle").removeClass("active");
    });

    //Toolbox animation
    $(".toolbox").click(function(){
        $('#tool-nav ul li').addClass('cst-animate');
    }); 
    $(".nav-close-btn").click(function(){
        $('#tool-nav ul li').removeClass('cst-animate') ;
    });

    $(".toolbox").click(function () {
        $(this).addClass("active");
        $("#tool-nav").addClass("active");
    });
    
    $(".nav-close-btn").click(function () {
        $("#tool-nav").removeClass("active");
        $(".toolbox").removeClass("active");
    });
    //End Toolbox animation
  }

}
