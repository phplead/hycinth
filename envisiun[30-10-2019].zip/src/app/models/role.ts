﻿export enum Role {
    User = 'User',
    Admin = 'Admin',
    Vendor = 'Vendor'
}