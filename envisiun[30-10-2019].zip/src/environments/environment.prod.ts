export const environment = {
  production: true,
  apiUrl: 'http://49.249.236.30:3009/api/'
};
